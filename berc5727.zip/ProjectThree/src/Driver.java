import java.util.Scanner;

/**
 * Project #3 CS 2334, Section 010 March 28, 2016
 * <P>
 * This is the driver for the class.
 * </P>
 * 
 * @version 1.0
 */
public class Driver {

	public static void main(String[] args){
		Database x = new Database();
		Scanner scan = new Scanner(System.in);
		x.userInput();
	}
}